import React from "react";
const AddCustomerAdmin=()=>{
   return(<>
   <h1>AddCustomerAdmin</h1></>) 
}
export default AddCustomerAdmin;