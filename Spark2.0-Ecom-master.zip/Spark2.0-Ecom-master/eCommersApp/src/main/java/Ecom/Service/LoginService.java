package Ecom.Service;


public interface LoginService {
	
	

}
