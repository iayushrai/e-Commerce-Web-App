package Ecom.Enum;

public enum PaymentStatus {
	SUCCESSFUL,
	FAILED,
	PENDING
}
