package Ecom.Enum;

public enum OrderStatus {
	DELIVERED, PENDING, SHIPPED, CANCELED
}
