package Ecom.Enum;

public enum UserAccountStatus {
	ACTIVE,DEACTIVETE

}
