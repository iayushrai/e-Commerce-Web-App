package Ecom.Enum;

public enum UserRole {
	ROLE_ADMIN,
	ROLE_USER

}
