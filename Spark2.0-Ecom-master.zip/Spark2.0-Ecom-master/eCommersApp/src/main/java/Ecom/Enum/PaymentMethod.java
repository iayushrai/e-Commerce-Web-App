package Ecom.Enum;

public enum PaymentMethod {
	CASH, CREDIT_CARD, UPI

}
