package Ecom.Exception;

public class CartException extends RuntimeException {

	
	public CartException(String msg) {
		super(msg);
	}

}
