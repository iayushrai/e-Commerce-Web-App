package Ecom.Exception;

public class ShipperException extends RuntimeException {

	public ShipperException() {

	}

	public ShipperException(String msg) {
		super(msg);
	}

}
