package Ecom.Exception;

public class ShippingException extends RuntimeException{
	
	public ShippingException(String msg) {
		super(msg);
	}

}
