package Ecom.Exception;

public class UserException  extends RuntimeException{
	
	public UserException() {
		// TODO Auto-generated constructor stub
	}
	public UserException(String msg) {
		super(msg);
	}
}
