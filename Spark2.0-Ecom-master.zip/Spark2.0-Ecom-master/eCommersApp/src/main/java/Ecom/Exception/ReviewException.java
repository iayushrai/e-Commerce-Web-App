package Ecom.Exception;

public class ReviewException extends RuntimeException {
	public ReviewException() {
		
	}
	public ReviewException(String msg) {
		super(msg);
	}
}
