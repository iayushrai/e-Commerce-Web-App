package Ecom.SecurityConfig;

public interface SecurityConstants {
	
	public static final String JWT_KEY ="secretsfhsfjhdkjngdfjkgfgjdlkfjsdkfjsd";
	public static final String JWT_HEADER = "Authorization";

}
